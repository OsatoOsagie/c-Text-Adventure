#include <iostream>
#include <vector>
#include <fstream>
#include <stdlib.h> /* srand, rand */
//    std::cout
#include <algorithm> // std::find
// #include <vector>
#include <map>
#include <string>
#include <time.h>

using std::vector;

#include "json.hpp"
using namespace std;

// for convenience
using json = nlohmann::json;

#include "Program.h"
#include "Room.cpp"


Program::Program(string map)
{
    currentRoom_ = nullptr;
    SetupRooms(map);
    finished_ = false;

    playerObjects_.clear();
}


void Program::Run()
{
    currentRoom_->OutputRoomInfo();
    currentRoom_->outputNeighbors();
    string status = "";
    while (!finished_)
    {

        cout << endl
             << endl;

        status = ExecuteInput();

        cout << "\t" << status << endl;
    }
}

void Program::SetupRooms(string map)
{
    ifstream fin(map);
    json j;   // object that represents the json data
    fin >> j; // read from file into j
    enemyCount_ = 0;

    int numOfRooms = j["rooms"].size(); //total size of the rools in the array
    int numOfEnemies = j["enemies"].size(); //total enemies in the map
    
    string id, name, description, northId, southId, eastId, westId, currentRoom, enemy, enemiesKilledBy;

    vector<string> objects;
    vector<string> enemiesVector;
    // vector<string> enemiesKilledBy;
    vector<string> enemiesV;
    std::map<std::string, string> enemies;
    std::map<std::string, string> enemiesCryptonite;

    for (int i = 0; i < numOfEnemies; i++)
    {
        string name = j["enemies"][i]["id"];
        string initRooom = j["enemies"][i]["initialroom"];
        string killedBy = j["enemies"][i]["killedby"];
         
        enemies.insert({name, initRooom});
        enemiesCryptonite.insert({name, killedBy});
    }

    for (int i = 0; i < numOfRooms; i++)
    {

        // CreateRoom( id, name, description, northId, southId, eastId, westId );
        enemiesVector.clear();
        objects.clear();
        id = j["rooms"][i]["id"].get<string>();
        description = j["rooms"][i]["desc"].get<string>();
        northId = j["rooms"][i]["n"].get<string>();
        southId = j["rooms"][i]["s"].get<string>();
        eastId = j["rooms"][i]["e"].get<string>();
        westId = j["rooms"][i]["w"].get<string>();
        objects = j["rooms"][i]["obj"].get<vector<string>>();

       
for (auto it = enemies.begin(); it != enemies.end(); ++it){
    if (it->second == id){
    enemiesVector.push_back(it->first);
           
            enemyCount_++;
            enemiesKilledBy = enemiesCryptonite[it->first];
    }
        
}
        // if (!(enemies.find(id) == enemies.end()))
        // {

        //     enemiesVector.push_back(enemies[id]);
           
        //     enemyCount_++;
        //     enemiesKilledBy = enemiesCryptonite[enemies[id]];
            
        // }

        //create a room object for every room
        CreateRoom(id, description, northId, southId, eastId, westId, objects, enemiesVector, enemiesKilledBy);
    }

    currentRoom = j["player"]["initialroom"].get<string>();//current room of the player

    currentRoom_ = m_rooms[currentRoom];
    health_ = j["player"]["health"].get<int>();
}


void Program::CreateRoom(string id, string description, string north, string south, string east, string west, vector<string> obj, vector<string> enemies, string enemiesKilledBy)
{

shared_ptr<Room> room(new Room(id, description, obj, enemies, enemiesKilledBy));
    m_rooms.insert({id,room});
    m_rooms[id]->setNeighbors(north, south, east, west);
}

string Program::GetStringLine(const string &message = "")
{
    if (message != "")
    {
        cout << " " << message << endl;
    }
    string choice;
    cout << endl
         << " >> ";
    getline(cin, choice);
    cout << endl;
    return choice;
}

string Program::ToLower(const string &val)
{
    string upper = "";
    for (unsigned int i = 0; i < val.size(); i++)
    {
        upper += tolower(val[i]);
    }
    return upper;
}

string Program::ExecuteInput()
{
cout<< "enemies "<<enemyCount_<<endl;
    string status = "";

    string userInput = GetStringLine("Now what?");
    string objToKill = currentRoom_->GetObjToKill();
    vector<string> objects = currentRoom_->GetObjects();
    vector<string> enemies = currentRoom_->GetEnemies();

    bool userInputMovement = false;

if(ToLower(userInput).find("exit") != std::string::npos){
    finished_ = true;
            cout << "You ended the game" << endl;
            exit(0);

}

if(ToLower(userInput).find("list commands") != std::string::npos){
     userInputMovement = true;
            cout << "You can use the following commands: \n 1. 'take (item name)' to take items \n 2. 'kill (enemy name)' to kill enemy\n 3. 'go (direction)' to change room \n 4. 'exit' to quit game \n 5. 'list items' to see your weapons" << endl;
           

}
    


    if (enemies.size() != 0 && ToLower(userInput).find("kill") == std::string::npos)
    {
        userInputMovement = true;
        int randNum;
        srand(time(NULL));
        /* generate secret number between 1 and 10: */
        randNum = rand() % 100;
        if (randNum >= 50)
        {
            finished_ = true;
            cout << "You've been killed by the enemy" << endl;
            exit(0);
        }
    }


    
    if (ToLower(userInput).find("list items") != std::string::npos)
    {

        userInputMovement = true;

        if (playerObjects_.size() == 0)
        {
            cout << "no items found" << endl;
        }
        else
        {
            for (string s : playerObjects_)
            {

                cout << s << endl;
            }
        }
    }

    for (int i = 0; i < 4; i++)
    {
        Direction direction = Direction(i);

        string command1 = ToLower(GetDirectionString(direction));
        string command2 = command1.substr(0, 1);

        if (userInput.find(command1) != std::string::npos)
        {
            userInputMovement = true;
            if (currentRoom_->CanGo(direction))
            {

                status = "You went " + GetDirectionString(direction);
                string key = currentRoom_->GetNeighborId(direction);
                currentRoom_ = m_rooms[key];
                currentRoom_->OutputRoomInfo();
                currentRoom_->outputNeighbors();
            }
            else
            {
                status = "You cannot go " + GetDirectionString(direction) + " here!";
                break;
            }
        }
    }

int counter = 0;
    for (string s : objects)
    {
       
        if (ToLower(userInput).find("take") != std::string::npos && ToLower(userInput).find(s) != std::string::npos)
        {
            userInputMovement = true;
            if ( std::find(playerObjects_.begin(), playerObjects_.end(), s) != playerObjects_.end() ){
                 cout << "You already have a " << s << endl;

            }else{
                playerObjects_.push_back(s);
                 cout << "You picked up a " << s << endl;
            }
            

           
            
        } else if(ToLower(userInput).find("take") != std::string::npos && ToLower(userInput).find(s) == std::string::npos){
             counter++;
            userInputMovement = true;
            if(counter==objects.size()){
            cout << "No such item found, you can only take available objects in the room" << endl;
            }
            
            
        }
    }

    int enemiesCount = 0;
    bool monster= false;
    string monster_name;

   
    


    for (string s : enemies)
    {
        enemiesCount++;
        

        if (ToLower(userInput).find(s) != std::string::npos && ToLower(userInput).find("kill") != std::string::npos)
        {
            userInputMovement = true;

            if (std::find(playerObjects_.begin(), playerObjects_.end(), objToKill) != playerObjects_.end())
            {
                cout << "You killed the " + s << endl;
                if (s == "goblin")
                {

                    for (string s : playerObjects_)
                    {

                        if (s == "grenade")
                        {

                            if (playerObjects_.size() == 1)
                            {
                                playerObjects_.clear();
                            }
                            else
                            {

                                // std::vector<int>::iterator it = std::find(playerObjects_.begin(), playerObjects_.end(), "grenade");
                                playerObjects_.erase(std::remove(playerObjects_.begin(), playerObjects_.end(), "grenade"), playerObjects_.end());
                            }
                        }
                    }
                }
                
                 enemies.erase(std::remove(enemies.begin(), enemies.end(), s), enemies.end());
                 
                enemyCount_--;
    
              

                if (enemyCount_ == 0)
                {
                    cout << "CONGRATULATIONS!! you have completed the game" << endl;
                    finished_ = true;
                    exit(0);
                }

                
                   
                

                currentRoom_->updateEnemy(enemies);
                currentRoom_->OutputRoomInfo();
                currentRoom_->outputNeighbors();
                break;
            }
            else
            {
                cout << "You need a " << objToKill << " to kill this enemy" << endl;
                cout << "The " << s << " attcked you and you died......GAME OVER!" << endl;
                finished_ = true;
                exit(0);
            }
        }
    }

    if (!userInputMovement)
    {
        status = "Unknown command- use 'list commands' to see commands";
    }

    return status;
}



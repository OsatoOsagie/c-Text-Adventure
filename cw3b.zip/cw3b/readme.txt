#c++ Text Adventure
An adventure game built using c++

#How to pay
1. run the make in the terminal 
2. run ./main map(1/2/3).json

#key concepts
1. The game is only complete when all the enemies are defeated.
2. if there is an enemy in the room and you do anything other than kill it there is a 50% chance it will kill you
3. A grenade can only be used once.
4. Not all objects are useful
5. each room may have multiple enemies
6. Users cannot take the same item more than once



#Commands:
1."take (weapon name)" to pick up weapon
2."Go (direction)" to change direction
3. "exit" to end game 
4. "kill (enemy name)" to kill enemy
5. "list items" prints out all the weapons the player currently has
6. "list commands" prints out a list of all the allowed commands

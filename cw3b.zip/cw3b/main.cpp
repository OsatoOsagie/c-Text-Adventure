#include <iostream>
using namespace std;

#include "Program.cpp"
#include "json.hpp"

using namespace std;
using json = nlohmann::json;
int main(int args, char *argsv[])
{
    string map = argsv[1];
    Program program(map);
    program.Run();
}
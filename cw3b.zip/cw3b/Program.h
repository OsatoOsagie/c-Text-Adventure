#ifndef PROGRAM_H

#define PROGRAM_H
#include <iostream>
#include <vector>
#include <fstream>
#include <stdlib.h>  
#include <algorithm> 
#include <map>
#include <string>
#include <time.h>
#include <memory> 

using std::vector;

#include "json.hpp"
// for convenience

#include "Room.h"

class Program
{
public:
//default constructor, takes a map as an argument
    Program(string map);
    //starts the game
    void Run();

private:
    // Room *currentRoom_;

    vector<Room> rooms_;
    //current room the player is in
    shared_ptr<Room> currentRoom_;
    //a map of each room and its id
    map<string, shared_ptr<Room> > m_rooms;
    //sets up 
    void SetupRooms(string map);
    string GetStringLine(const string &message);
    //creates a room object for every room in the map
    void CreateRoom(string id, string description, string north, string south, string east, string west, vector<string> vect, vector<string> enemies, string enemiesKilledBy);
    //changes string to lowercase
    string ToLower(const string &val);

    //takes care of the users commands
    string ExecuteInput();
    //used to determine if a game is ungoing
    bool finished_;
    int health_;
    //contains all the objects a player currently has
    vector<string> playerObjects_;
    //a count of all the enemies in the map
    int enemyCount_;
};

#endif
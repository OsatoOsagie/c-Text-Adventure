#ifndef ROOM_H
#define ROOM_H

#include <iostream>
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
/* srand, rand */
// std::cout
#include <algorithm> // std::find
// #include <vector>
#include <map>
#include <string>

using std::vector;
using namespace std;

enum Direction
{
    NORTH = 0,
    SOUTH = 1,
    EAST = 2,
    WEST = 3
};


string GetDirectionString(Direction direction)
{
    if (direction == NORTH)
    {
        return "NORTH";
    }
    else if (direction == SOUTH)
    {
        return "SOUTH";
    }
    else if (direction == EAST)
    {
        return "EAST";
    }
    else if (direction == WEST)
    {
        return "WEST";
    }
    else
    {
        return "UNKNOWN";
    }
}

struct Room
{

    // constructor
    Room(string id, string desc, vector<string> obj, vector<string> enemies, string enemiesKilledBy);

    // sets the neighbours of the current room 
    void setNeighbors(string north, string south, string east, string west);
    void Setup(string name, string description, vector<string> objects, vector<string> enemies, string enemiesKilledBy);
    // prints the neighbours of the current room 
    void printNeighbours();

   
 
// gets objects in a room
    vector<string> GetObjects();
    void OutputRoomInfo();
    void outputNeighbors();
    //outputs the directions player can move in
    bool CanGo(Direction direction);

    void updateEnemy(vector<string> enemies);
    string GetNeighborId(Direction direction);
    string GetId();
    // gets objects to kill enemies in room 
    string GetObjToKill();
    vector<string> GetEnemies();

    //id of the room
    string id;
    //decription of the rool
    string desc_;
    string neighborIds[4];
    vector<string> objects;
    vector<string> enemies;
    //object that kills enemy
    string enemiesKilledBy;
};

#endif


#include <iostream>
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <stdlib.h>  /* srand, rand */
                     // std::cout
#include <algorithm> // std::find
// #include <vector>
#include <map>
#include <string>
#include <time.h>
#include "Room.h"

using namespace std;

Room::Room(string id, string desc, vector<string> obj, vector<string> enemies, string enemiesKilledBy)
{
    Setup(id, desc, obj, enemies, enemiesKilledBy);
}

void Room::Setup(string name, string description, vector<string> objects, vector<string> enemies, string enemiesKilledBy)
{
    this->id = name;
    this->desc_ = description;
    this->objects = objects;
    this->enemies = enemies;
    this->enemiesKilledBy = enemiesKilledBy;

    for (int i = 0; i < 4; i++)
    {
        neighborIds[i] = "NULL";
    }
}

void Room::setNeighbors(string north, string south, string east, string west)
{
    neighborIds[NORTH] = north;
    neighborIds[SOUTH] = south;
    neighborIds[EAST] = east;
    neighborIds[WEST] = west;
}

void Room::printNeighbours()
{
    cout << "\t You can go: ";

    for (int i = 0; i < 4; i++)
    {
        if (neighborIds[i] != "NULL")
        {
            cout << GetDirectionString(Direction(i)) << " ";
        }
    }

    cout << endl;
}

void Room::OutputRoomInfo()
{
    cout << ".............................................." << endl
         << "\t" << id << endl
         << desc_ << endl
         << ".............................................."
         << endl;
    cout << ".............................................." << endl;
    cout << "Objects available: " << endl;

    for (string s : objects)
        cout << s << "\n"
             << endl;
    cout << ".............................................." << endl;

    cout << "Enemies: " << endl;
    if (enemies.size() == 0)
    {
        /* code */
        cout << "NO Enemies here" << endl;
    }
    else
    {
        for (string s : enemies)
        {

            cout << s << "\n"
                 << endl;
        }
    }
}

void Room::outputNeighbors()
{
    cout << "OPTIONS"
         << "\t You can go: ";

    for (int i = 0; i < 4; i++)
    {
        if (neighborIds[i] != "")
        {
            cout << GetDirectionString(Direction(i)) << " ";
        }
    }

    cout << endl;
}

bool Room::CanGo(Direction direction)
{
    for (int i = 0; i < 4; i++)
    {
        if (direction == Direction(i) && neighborIds[i] != "")
        {
            return true;
        }
    }

    return false;
}

string Room::GetNeighborId(Direction direction)
{
    return neighborIds[direction];
}

string Room::GetId()
{
    return id;
}

string Room::GetObjToKill()
{
    return enemiesKilledBy;
}

vector<string> Room::GetObjects()
{
    return objects;
}

vector<string> Room::GetEnemies()
{
    return enemies;
}

void Room::updateEnemy(vector<string> enemies)
{
    this->enemies = enemies;
}
